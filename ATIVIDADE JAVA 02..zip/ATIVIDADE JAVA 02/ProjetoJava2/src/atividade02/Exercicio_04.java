package atividade02;

import java.util.Scanner;

public class Exercicio_04 {

	public static void main(String[] args) {
		/* 4. Elabore uma classe que pergunta o nome da capital do estado do Tocantins, a
função era repetir até o usuário responder Palmas. */
		String nome="";
		Scanner teclado = new Scanner(System.in);	
		do {
			System.out.println("Qual o  nome da capital do Estado do Tocantins? ");
			nome = teclado.nextLine();
		}while (!nome.equalsIgnoreCase("Palmas"));
		System.out.println("Você acertou!");
	}

	}

