package atividade02;

import java.util.Scanner;

public class Exercicio_02 {

	public static void main(String[] args) {
		/* 2. Faça um classe que receba a idade de dez pessoas e que calcule e mostre a
	quantidade de pessoas com idade maior ou igual a 18 anos. */
		int vetor[ ]= new int [10];
		int i, maior=0, menor=0;
		Scanner teclado = new Scanner(System.in);
		System.out.println("Informe a idade de 10 pessoas: ");
		 for (i=0; i<10; i++) {
			 vetor[i] = teclado.nextInt();
		 
		 if (vetor[i] >= 18) {
			maior++;
		 }else {
			 menor++;
		 }
	}
		 System.out.printf("A quantidade de pessoas maiores de idade é de : %d",  maior);
	}

}
