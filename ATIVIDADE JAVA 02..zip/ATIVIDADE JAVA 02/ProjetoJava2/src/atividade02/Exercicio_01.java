package atividade02;

import java.util.Scanner;

public class Exercicio_01 {

	public static void main(String[] args) {
		/* 1. Escreva um programa em Java que recebe um inteiro e diga se é par ou ímpar.
		Use o operador matemático % (resto da divisão ou módulo).*/
		Scanner teclado = new Scanner(System.in);
		System.out.println("Informe um número: ");
		int n1 = teclado.nextInt();
		if (n1 % 2==0 && n1 != 0) {
			System.out.println("O número é par. ");
		}else if (n1 % 2 != 0 && n1 != 0) {
			System.out.println("O número é ímpar");
		}else {
			System.out.println("O número é nulo.");
		}
		teclado.close();

	}

}
