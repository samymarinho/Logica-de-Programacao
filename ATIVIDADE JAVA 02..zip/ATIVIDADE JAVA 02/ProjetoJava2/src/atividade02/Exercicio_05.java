package atividade02;

import java.util.Scanner;

public class Exercicio_05 {

	public static void main(String[] args) {
		/* 5. Dado o valor do produto e a forma de pagamento: [1]= à vista; [2]= à prazo. Se
o produto for pago à vista aplique um desconto de 15% antes de mostrar o valor
final, senão informe o mesmo valor do produto. */
		double desconto = 0.15;
		Scanner teclado = new Scanner(System.in);	
		System.out.println(" Valor do produto: ");
		double n1 = teclado.nextDouble();
		System.out.println(" ------ PAGAMENTO -------- \n");
		System.out.println("[1] - À VISTA ");
		System.out.println("[2] - À PRAZO ");
		int opc = teclado.nextInt();
		switch (opc) {
		case 1: 
			desconto = 0.15 * n1;
			desconto = n1 - desconto;
			System.out.printf("Valor final: R$ %.2f", desconto);
			break;
		case 2: 
			System.out.printf("Valor final: R$ %.2f", n1);
			break;
		default:
			System.out.println("Opção inválida!");
		}
	}

}
