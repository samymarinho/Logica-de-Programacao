package atividade02;

import java.util.Scanner;

public class Exercicio_03 {

	public static void main(String[] args) {
		/* 3. Escreva uma classe que solicita um número maior que 50, caso o número não
seja maior que 50 a função solicita novamente até o usuário digitar um número
correspondente. */
		int n;
		int maior = 50;
		Scanner teclado = new Scanner(System.in);	
		do {
			System.out.println("Informe um valor maior que 50: ");
			n = teclado.nextInt();
		}while (n <= maior);
	}

}
